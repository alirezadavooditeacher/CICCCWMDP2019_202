package registrationSystem;

public class RegistrationSystem {

}
