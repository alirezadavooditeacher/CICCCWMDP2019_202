package assigments;

import java.util.Scanner;

public class Problem4 {

    public static int add(Scanner c, int number) {
        int sum = 0;

        while (number!= 0) {
            sum = sum + number;
            System.out.println("Enter number: ");
            number = Integer.parseInt(c.nextLine());

            if (number == 0) {
                return sum;
            }

        }
     return 0;
    }
}



