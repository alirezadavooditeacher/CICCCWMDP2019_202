package assigments;

import java.util.Scanner;

public class Problem5 {

    public static int valueNumber(Scanner c, int number) {
        int sum = 0; int n = 0;

        while (number!= 0) {
            n = number%10;
            number = number /10;
            sum = sum + n;
        }
        return sum;

    }
}
