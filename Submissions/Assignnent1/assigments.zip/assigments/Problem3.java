package assigments;

import java.util.Scanner;

public class Problem3 {
    public static void problem3() {
        int number;
        Scanner in = new Scanner(System.in);

        System.out.println("Enter number: ");
        number = Integer.parseInt(in.nextLine());
    }


    public static boolean isInputValid(int number){
        if (number < 1){
            return false;
        }else{
            return primeNumber(number);
        }
    }
    public static boolean primeNumber(int number){
        for (int i = 2; i < number; i++){
                if( number%i==0){
                    return false;
                }else{
                    return true;
                }

        }

        return false;
    }
}
