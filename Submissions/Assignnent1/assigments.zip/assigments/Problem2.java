package assigments;

public class Problem2 {


    public static void printShape1(int input, int shape) {

        if (shape == 1) {
            System.out.println("Shape 1");
            for (int i = input; i > 0; i = i - 2) {
                //System.out.println(i);
                for (int j = i; j < i; j = j + 1) {

                    System.out.print("*");

                }
                System.out.println();
            }
        }
    }

    public static void printShape2(int input, int shape) {
        if (shape == 2){
            System.out.println("Shape 2:");
            for(int i = input; i>0; i--){
                for (int j = i; j>0; j--) {
                    System.out.print('*');
                }
                System.out.println();
            }

        }

    }


    public static void printShape3(int input, int shape) {
        if (shape ==3){
            System.out.println("Shape 3");
            for(int i = 1; i<=input; i++){
                for (int j = 1; j<= i; j++) {
                    if (j <= i) {
                        System.out.printf("%2s", String.valueOf("*"));
                    }
                }
            }
            System.out.println();
        }

    }

}
