package assigments;
import java.util.Scanner;

//Problem1
// Design for an function which takes 2 operands (number) and one operator (plus, minus,
// multiplication and division) and apply the operator on the operands and print the result.
// Note: If operand1 is a non-zero number and the operand2 is zero, then the program should
// not perform the division operand and should print the operation is not possible because one
// number if zero (this is only for division operator).


public class Problem1 {


    public static int sum(int number1, int number2){
       return number1 + number2;
    }

    public static int minus(int number1, int number2){
        return number1 - number2;
    }

    public static int multiplicat(int number1, int number2) {
        return number1 * number2;
    }

    public static float div(float number1, float number2) {
        float result = 0;
        if(number2 == 0) {
            System.out.println("Operation is not possible");
        }else{

            result = number1 / number2;

        }
        return result;
    }

    public static float operator(int number1, int number2, char operator) {
        if (operator == '+') {
            return(sum(number1, number2));
        }else if(operator == '-') {
            return(minus(number1, number2));
        }else if(operator == '*') {
            return(multiplicat(number1, number2));
        }else if(operator == '/') {
            return(div(number1, number2));
        }
        return 0;
    }

}
