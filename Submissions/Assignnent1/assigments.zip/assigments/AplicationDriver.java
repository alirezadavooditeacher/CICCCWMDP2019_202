package assigments;

import java.util.Scanner;

public class AplicationDriver {

    public static void main(String[] args) {
        //problem1();
        //problem2();
        //problem3();
        //problem4();
        problem5();
        //inputs();
    }

//    public static void problem1() {
//        int number1, number2;
//        char operator;
//        Scanner in = new Scanner(System.in);
//
//        System.out.println("Enter first number");
//        number1 = Integer.parseInt(in.nextLine());
//
//        System.out.println("Enter second number");
//        number2 = Integer.parseInt(in.nextLine());
//
//        System.out.print("Enter operator (+, -, *, /)");
//        operator = in.nextLine().charAt(0);
//
//        //Test Program1
//        float result = Problem1.operator(number1, number2, operator);
//        System.out.println(result);
//
//


    //-----------------------------------------------------------------------------------------
//    public static void problem2() {
//        int input, shape;
//        Scanner in = new Scanner(System.in);
//
//        System.out.println("Enter stars number");
//        input = Integer.parseInt(in.nextLine());
//
//        System.out.println("Enter shape number");
//        shape = Integer.parseInt(in.nextLine());
//
//        //Problem2.printShape1(input, shape);
//        Problem2.printShape2(input, shape);
//        //Problem2.printShape3(input, shape);
//    }
//----------------------------------------------------------------------------------------
//    public static void problem3(){
//        int number;
//        Scanner in = new Scanner(System.in);
//
//        System.out.println("Enter number: ");
//        number = Integer.parseInt(in.nextLine());
//
//        System.out.println(Problem3.primeNumber(number));
//
//    }

//--------------------------------------------------------------------------------------------

    //     public static void inputs() {
//         int A, B;
//         Scanner in = new Scanner(System.in);
//
//         System.out.println("Enter first number");
//         A = Integer.parseInt(in.nextLine());
//
//         System.out.println("Enter second number");
//         B = Integer.parseInt(in.nextLine());
//
//         float result = Problem8.division(A, B);
//         System.out.println(result);
//     }
//-------------------------------------------------------------------------------------------------
//        public static void problem4() {
//            int number; int n = 0;
//            Scanner in = new Scanner(System.in);
//
//            System.out.println("Enter number: ");
//            number = Integer.parseInt(in.nextLine());
//
//
//            int result = Problem4.add(in, number);
//            System.out.println(result);
//        }
//        -------------------------------------------------------------------------------------------------
        public static void problem5() {
            int number;
            int n = 0;
            int sum = 0;
            Scanner in = new Scanner(System.in);

            System.out.println("Enter number: ");
            number = Integer.parseInt(in.nextLine());


            int result = Problem5.valueNumber(in, number);
            System.out.println(result);
        }

}