package assigments;

import java.util.Scanner;

public class Problem8 {
    public static void inputs() {
        int A, B;
        Scanner in = new Scanner(System.in);

        System.out.println("Enter first number");
        A = Integer.parseInt(in.nextLine());

        System.out.println("Enter second number");
        B = Integer.parseInt(in.nextLine());
    }

    public static int division(int A,int B){
        return A/B;
    }
}
