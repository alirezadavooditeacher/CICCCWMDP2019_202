import java.util.ArrayList;

import program0.*;
import program1.*;

public class mainDriver {
	public static void main(String[] args) {
		prog1();
	}
	public static void prog0() {
		Holidays h1=new Holidays("Independce Day",4,"July");
		Holidays h2=new Holidays("Colombian Independence",20,"July");
		Holidays h3=new Holidays("Colombia:Boyacas Fight",7,"August");
		//Testing method isSameMonth
		System.out.println("Expected:True.   Actual:"+Holidays.isSameMonth(h1, h2));
		System.out.println("Expected:false.   Actual:"+Holidays.isSameMonth(h1, h3));
		//testing avgDate method
		
		System.out.printf("Expected 10.3   Actual %.1f",Holidays.avgDate(Holidays.getListOfHolidays()));
		
	}
	public static void prog1() {
		Movies m1=new Movies("Casino Royale","EON Productions","PG-13");
		Movies m2=new Movies("Toy Story","PIXAR");
		Movies m3=new Movies("Lion King","Disney");
		//Testing method getPG
		ArrayList<String> moviesPGList=Movies.getPG(Movies.getMoviesList());
		System.out.println("Expected: Toy Story,LionKing. Actual: "+moviesPGList);
		
		
	}
}
