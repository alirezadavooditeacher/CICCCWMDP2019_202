package program1;

import java.util.ArrayList;

public class Movies {
	private String title;
	private String studio;
	private String rating;
	static ArrayList<Movies> moviesList=new ArrayList<Movies>();

	public Movies(String movieTitle,String movieStudio,String movieRating) {
		super();
		this.title=movieTitle;
		this.studio=movieStudio;
		this.rating=movieRating;
		moviesList.add(this);
	}
	public Movies(String movieTitle,String movieStudio) {
		super();
		this.title=movieTitle;
		this.studio=movieStudio;
		this.rating="PG";
		moviesList.add(this);

	}
	public String getTitle() {
		return title;
	}
	public String getStudio() {
		return studio;
	}
	public String getRating() {
		return rating;
	}
	public static ArrayList<Movies> getMoviesList() {
		return moviesList;
	}
	public static ArrayList<String> getPG(ArrayList<Movies> moviesList){
		ArrayList<String> listOfPGMovies=new ArrayList<String>();
		for(int i=0;i<moviesList.size();i++) {
			if(moviesList.get(i).getRating()=="PG") {
				listOfPGMovies.add(moviesList.get(i).getTitle());
			}
		}
		return listOfPGMovies;
	}
}
