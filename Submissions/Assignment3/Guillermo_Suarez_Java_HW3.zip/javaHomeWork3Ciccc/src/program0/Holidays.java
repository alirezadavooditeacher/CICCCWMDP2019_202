package program0;

import java.util.ArrayList;

public class Holidays {
	private String name;
	private int day;
	private String month;
	static ArrayList<Holidays> listOfHolidays=new ArrayList<Holidays>();
	
	public Holidays(String holiName,int holiDay, String holiMonth) {
		super();
		this.name=holiName;
		this.day=holiDay;
		this.month=holiMonth;
		listOfHolidays.add(this);
	}

	private String getName() {
		return name;
	}

	private int getDay() {
		return day;
	}

	private String getMonth() {
		return month;
	}
	

	public static boolean isSameMonth(Holidays holidayA, Holidays holidayB) {
		String monthA=holidayA.getMonth();
		String monthB=holidayB.getMonth();
		if(monthA==monthB) {
			return true;
		}
		else {
			return false;
		}
	}
	public static double avgDate(ArrayList<Holidays> holidaysList) {
		int sumDayOfHolidays=0;
		int averageDivisor=0;
		for(int i=0;i<holidaysList.size();i++) {
			int holidayDay=holidaysList.get(i).getDay();
			sumDayOfHolidays=sumDayOfHolidays+holidayDay;
			averageDivisor++;
		}
		double result=1.0*sumDayOfHolidays/averageDivisor;
		return result;
	}

	public static ArrayList<Holidays> getListOfHolidays() {
		return listOfHolidays;
	}
	
	
}
